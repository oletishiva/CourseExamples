package multithreadingconcepts;

public class Test {
	
	
	/*
	 * Ways to create thread:--
	 * 
	 * 1. by extending Thread class
	 * 2. Implement Runnable interface
	 * 
	 * 
	 * 
	 */

}
