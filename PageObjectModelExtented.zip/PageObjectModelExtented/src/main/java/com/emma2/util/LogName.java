package com.emma2.util;

public enum LogName {
	CurrentTestClassLog,CurrentGlobalLog,CurrentTestCaseLog,CurrentSiteCoreLog
}
