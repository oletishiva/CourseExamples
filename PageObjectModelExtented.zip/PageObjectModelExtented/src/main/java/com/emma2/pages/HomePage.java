package com.emma2.pages;

import org.openqa.selenium.support.ui.ExpectedCondition;


public class HomePage  extends BasePage{


    @Override
    protected ExpectedCondition getPageLoadCondition() {
        return null;
    }
}
