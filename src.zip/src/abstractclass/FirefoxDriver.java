package abstractclass;

public abstract class FirefoxDriver extends WebDriver {

	public abstract void getFirefoxInstance();

}
