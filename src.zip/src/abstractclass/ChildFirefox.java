package abstractclass;

public class ChildFirefox extends FirefoxDriver {
	
	
	public void childMethod(){
		
		
	}

	@Override
	public void click() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sendKeys() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getTitle() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getFirefoxInstance() {
		// TODO Auto-generated method stub
		
	}

}
