package inheritance;

public class BullDog extends Dog {
	
	
	public static void main(String[] args) {
		
		BullDog obj = new BullDog();
		obj.sound();
		
		
	}

}
