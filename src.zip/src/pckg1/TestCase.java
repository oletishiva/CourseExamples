package pckg1;

public class TestCase {
	
	public static void main(String[] args) {
		
		ClassA obj = new ClassA();
		obj.add();
		
		ClassB obj2 = new ClassB();
		obj2.show();
		
	}

}
