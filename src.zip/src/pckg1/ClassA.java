package pckg1;

public class ClassA {
	
	
	public void add(){
		
		
	}

}
