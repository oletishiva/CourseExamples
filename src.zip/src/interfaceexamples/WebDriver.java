package interfaceexamples;

public interface WebDriver {
	
	
	public void click();
	public void sendKeys();

}
