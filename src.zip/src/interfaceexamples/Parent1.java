package interfaceexamples;

public interface Parent1 {
	
	public void show();

}
