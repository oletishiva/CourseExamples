package interfaceexamples;

public class ChromeDriverChild extends ChromeDriver {

}
