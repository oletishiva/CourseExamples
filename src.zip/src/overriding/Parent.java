package overriding;

public class Parent {
	
	
	public void show(){
		
		
	}
	
	public static void add(){
		
		System.out.println("add - Parent()");
	}

}
